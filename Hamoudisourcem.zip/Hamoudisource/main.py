cat > main.py << 'EOF'
#!/usr/bin/env python3
from telethon import TelegramClient, events
import asyncio
import random

API_ID = 12548557
API_HASH = "b4ddb955fd4c18d7f38d0dd784e2c760"
SOURCE_NAME = "✦ 𝐒𝐎𝐔𝐑𝐂𝐄 𝐁𝐋𝐀𝐂𝐊 𝐃𝐄𝐕𝐈𝐋 ✦"
DEV_USERNAME = "@BL_TH"

print("🚀 " + SOURCE_NAME + " - جاري التشغيل...")

async def main():
    client = TelegramClient("sessions/black_devil", API_ID, API_HASH)
    
    await client.start()
    me = await client.get_me()
    
    print("✅ تم التسجيل كـ: " + me.first_name)
    
    @client.on(events.NewMessage(pattern='.معلومات'))
    async def info_handler(event):
        user = await event.get_sender()
        await event.reply("✦ معلومات الحساب ✦\n👤 الاسم: " + user.first_name + "\n🆔 ايدي: " + str(user.id) + "\n👑 المطور: " + DEV_USERNAME)
    
    @client.on(events.NewMessage(pattern='.بداية'))
    async def start_handler(event):
        await event.reply("✦ مرحبا بك ✦\n🎯 الأوامر:\n• .معلومات\n• .حب\n👑 المطور: " + DEV_USERNAME)
    
    @client.on(events.NewMessage(pattern='.حب'))
    async def love_handler(event):
        await event.reply("❤️🧡💛💚💙💜")
    
    print("✨ السورس شغال! اكتب .بداية")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
EOF